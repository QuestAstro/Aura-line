package dev.auraline;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * AURA LINE v0.1 - narrow edge glass tube with a direction-aware moving liquid highlight.
 * Canvas rendering is independent from SystemUI resources and has no numeric readout.
 */
public final class AuraLineView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF track = new RectF();
    private float level = 0.42f;
    private float particle = 1f;
    private int direction = 1;
    private ValueAnimator fillAnimator;
    private ValueAnimator particleAnimator;

    public AuraLineView(Context context) {
        super(context);
        // Small isolated software layer keeps soft glow consistent across Samsung renderers.
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        setAlpha(0f);
    }

    private float dp(float amount) {
        return amount * getResources().getDisplayMetrics().density;
    }

    private static float clamp(float val) {
        return Math.max(0f, Math.min(1f, val));
    }

    /** newLevel is 0..1, dir > 0 for up, dir < 0 for down. */
    public void showLevel(float newLevel, int dir) {
        newLevel = clamp(newLevel);
        direction = dir >= 0 ? 1 : -1;
        if (fillAnimator != null) fillAnimator.cancel();
        if (particleAnimator != null) particleAnimator.cancel();
        float oldLevel = level;
        fillAnimator = ValueAnimator.ofFloat(oldLevel, newLevel);
        fillAnimator.setInterpolator(new DecelerateInterpolator(1.65f));
        fillAnimator.setDuration(330);
        fillAnimator.addUpdateListener(a -> {
            level = (float) a.getAnimatedValue();
            invalidate();
        });
        fillAnimator.start();
        particle = 0f;
        particleAnimator = ValueAnimator.ofFloat(0f, 1f);
        particleAnimator.setInterpolator(new DecelerateInterpolator(1.2f));
        particleAnimator.setDuration(480);
        particleAnimator.addUpdateListener(a -> {
            particle = (float) a.getAnimatedValue();
            invalidate();
        });
        particleAnimator.start();
        animate().cancel();
        animate().alpha(1f).setDuration(160).start();
    }

    public void disappear(Runnable after) {
        animate().cancel();
        animate().alpha(0f).setDuration(350).withEndAction(after).start();
    }

    private void resetPaint() {
        paint.reset();
        paint.setAntiAlias(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() - dp(18);
        float half = dp(6.2f);
        float top = dp(20);
        float bottom = getHeight() - dp(20);
        float radius = dp(6.2f);
        track.set(cx - half, top, cx + half, bottom);
        float fillTop = bottom - (bottom - top) * level;

        // Very faint ambient glow behind the glass: no large blocking panel.
        resetPaint();
        paint.setColor(0x1525AAFF);
        paint.setShadowLayer(dp(13), 0, 0, 0x265CE1FF);
        canvas.drawRoundRect(track, radius, radius, paint);
        paint.clearShadowLayer();

        // Dark transparent optical tube.
        resetPaint();
        paint.setShader(new LinearGradient(track.left, 0, track.right, 0,
                new int[]{0x293B536F, 0x8B122039, 0x5D7186AA, 0x294E698F},
                null, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(track, radius, radius, paint);
        paint.setShader(null);

        // Thin glass rim and a tiny reflective stripe on the inner left wall.
        resetPaint();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(0.85f));
        paint.setColor(0x75CBEFFF);
        canvas.drawRoundRect(track, radius, radius, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x8BE8FFFF);
        canvas.drawRoundRect(new RectF(track.left + dp(1.5f), top + dp(7),
                track.left + dp(2.4f), bottom - dp(7)), dp(1), dp(1), paint);

        // Liquid fill, naturally growing toward the top or shrinking downward.
        if (level > 0.001f) {
            RectF liquid = new RectF(track.left + dp(1.1f),
                    Math.max(top + dp(1.2f), fillTop),
                    track.right - dp(1.1f), bottom - dp(1.1f));
            if (liquid.bottom > liquid.top) {
                resetPaint();
                paint.setColor(0xC45AEAFF);
                paint.setShadowLayer(dp(11), 0, 0, 0x8C49DFFF);
                canvas.drawRoundRect(liquid, dp(5), dp(5), paint);
                paint.clearShadowLayer();
                paint.setShader(new LinearGradient(liquid.left, 0, liquid.right, 0,
                        new int[]{0xBD1A98DB, 0xE87BECFF, 0xFFBDFBFF, 0xDE36C8FB},
                        null, Shader.TileMode.CLAMP));
                canvas.drawRoundRect(liquid, dp(5), dp(5), paint);
                paint.setShader(null);
                resetPaint();
                paint.setColor(0xC8E6FFFF);
                canvas.drawRoundRect(new RectF(liquid.left + dp(1), liquid.top + dp(2),
                        liquid.left + dp(2), liquid.bottom - dp(2)), dp(1), dp(1), paint);
            }
        }

        // Traveling light bead: upward on volume up, downward on volume down.
        float y = direction > 0
                ? bottom - (bottom - top) * particle
                : top + (bottom - top) * particle;
        float movingAlpha = (float) Math.sin(Math.PI * particle);
        if (movingAlpha > 0.01f) {
            resetPaint();
            paint.setShader(new RadialGradient(cx, y, dp(21),
                    new int[]{Color.argb((int) (130 * movingAlpha), 91, 223, 255),
                            Color.argb((int) (45 * movingAlpha), 91, 223, 255),
                            Color.TRANSPARENT},
                    new float[]{0f, 0.3f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, y, dp(21), paint);
            resetPaint();
            paint.setColor(Color.argb((int) (215 * movingAlpha), 204, 250, 255));
            paint.setShadowLayer(dp(8), 0, 0, 0xFF8EF5FF);
            canvas.drawCircle(cx, y, dp(4.1f), paint);
            paint.clearShadowLayer();
        }

        // Shining meniscus at the current volume height (never a number).
        if (level > 0.04f) {
            resetPaint();
            paint.setColor(0xC2D6FCFF);
            paint.setShadowLayer(dp(4), 0, 0, 0xD643DEFF);
            canvas.drawCircle(cx, Math.max(top + dp(5), fillTop + dp(3)), dp(3.9f), paint);
            paint.clearShadowLayer();
        }
    }
}
