package dev.auraline;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.WindowManager;
import java.util.Arrays;

/** Runs in the SystemUI process via LSPosed. All window operations stay on its main thread. */
public final class AuraController {
    private static final String TAG = "AURA_LINE";
    private static final String VOLUME_ACTION = "android.media.VOLUME_CHANGED_ACTION";
    private static final String EXTRA_STREAM = "android.media.EXTRA_VOLUME_STREAM_TYPE";
    private static final String EXTRA_LEVEL = "android.media.EXTRA_VOLUME_STREAM_VALUE";
    private static final String EXTRA_OLD = "android.media.EXTRA_PREV_VOLUME_STREAM_VALUE";
    private static final int TYPE_VOLUME_OVERLAY = 2020; // AOSP internal volume overlay window type.
    public static final String REPLACE_SETTING = "aura_line_replace_stock";
    private static volatile AuraController instance;

    private final Context context;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AudioManager audio;
    private final WindowManager windowManager;
    private final int[] lastLevels = new int[16];
    private final long[] lastTimes = new long[16];
    private AuraLineView line;
    private boolean added;
    private boolean everAttached;
    private long eventId;
    private Runnable pendingHide;

    private AuraController(Context ctx) {
        Context applicationContext = ctx.getApplicationContext();
        context = applicationContext != null ? applicationContext : ctx;
        audio = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Arrays.fill(lastLevels, -1);
        register();
    }

    public static synchronized AuraController getOrCreate(Context ctx) {
        if (instance == null) instance = new AuraController(ctx);
        return instance;
    }

    public static AuraController get() { return instance; }
    public boolean isAttached() { return added || everAttached; }

    private int dp(float value) {
        return (int) (context.getResources().getDisplayMetrics().density * value + 0.5f);
    }

    private void register() {
        IntentFilter f = new IntentFilter();
        f.addAction(VOLUME_ACTION);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        try {
            context.registerReceiver(new BroadcastReceiver() {
                @Override public void onReceive(Context c, Intent intent) {
                    if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
                        handler.post(() -> removeNow());
                        return;
                    }
                    if (VOLUME_ACTION.equals(intent.getAction())) {
                        int stream = intent.getIntExtra(EXTRA_STREAM, AudioManager.STREAM_MUSIC);
                        int vol = intent.getIntExtra(EXTRA_LEVEL, -1);
                        int old = intent.getIntExtra(EXTRA_OLD, -1);
                        if (vol >= 0) update(stream, vol, old);
                    }
                }
            }, f, Context.RECEIVER_EXPORTED);
            Log.i(TAG, "Volume broadcast listener registered");
        } catch (Throwable error) {
            Log.e(TAG, "Failed to register volume listener", error);
        }
    }

    /** Supplemental signal from VolumeDialogControllerImpl, when present on the ROM. */
    public void onControllerUpdate(int stream) {
        if (audio == null) return;
        try { update(stream, audio.getStreamVolume(stream), -1); }
        catch (Throwable error) { Log.w(TAG, "Cannot read stream " + stream, error); }
    }

    private void update(int stream, int vol, int old) {
        if (stream < 0 || stream >= lastLevels.length || audio == null) return;
        int max;
        try { max = audio.getStreamMaxVolume(stream); }
        catch (Throwable ignored) { return; }
        if (max <= 0) return;
        long now = SystemClock.uptimeMillis();
        // Prevent controller hook + broadcast from generating two pulses per key press.
        if (lastLevels[stream] == vol && now - lastTimes[stream] < 600) return;
        int previous = (old >= 0) ? old : lastLevels[stream];
        lastLevels[stream] = vol;
        lastTimes[stream] = now;
        if (previous == vol) return;
        final float normalized = Math.min(1f, Math.max(0f, vol / (float) max));
        final int dir = previous < 0 || vol > previous ? 1 : -1;
        handler.post(() -> present(normalized, dir));
    }

    private void present(float level, int direction) {
        try {
            if (!added) {
                line = new AuraLineView(context);
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                        dp(54), dp(236), TYPE_VOLUME_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                        PixelFormat.TRANSLUCENT);
                lp.gravity = Gravity.END | Gravity.TOP;
                lp.y = dp(118);
                lp.x = 0;
                lp.setTitle("AURA LINE");
                try {
                    windowManager.addView(line, lp);
                    added = true;
                    everAttached = true;
                } catch (Throwable firstError) {
                    // Fallback if OEM policy denies the internal 2020 window type.
                    lp.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
                    windowManager.addView(line, lp);
                    added = true;
                    everAttached = true;
                }
            }
            eventId++;
            if (pendingHide != null) handler.removeCallbacks(pendingHide);
            line.showLevel(level, direction);
            final long hideId = eventId;
            pendingHide = () -> {
                if (hideId != eventId || line == null) return;
                line.disappear(() -> {
                    if (hideId == eventId) removeNow();
                });
            };
            handler.postDelayed(pendingHide, 1550);
        } catch (Throwable error) {
            Log.e(TAG, "Overlay failed (stock volume remains available)", error);
            removeNow();
        }
    }

    private void removeNow() {
        if (pendingHide != null) {
            handler.removeCallbacks(pendingHide);
            pendingHide = null;
        }
        if (added && line != null) {
            try { windowManager.removeViewImmediate(line); }
            catch (Throwable ignored) { }
        }
        added = false;
        line = null;
    }
}
