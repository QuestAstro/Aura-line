package dev.auraline;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

/** No Compose or libraries required: an on-device preview and a root-assisted safety switch. */
public final class MainActivity extends Activity {
    private AuraLineView demoLine;
    private int demoLevel = 55;
    private Switch replaceSwitch;

    private int dp(float v) {
        return (int) (getResources().getDisplayMetrics().density * v + 0.5f);
    }

    private TextView text(String content, int size, int color) {
        TextView v = new TextView(this);
        v.setText(content);
        v.setTextSize(size);
        v.setTextColor(color);
        return v;
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private void gap(LinearLayout parent, int dp) {
        View spacer = new View(this);
        parent.addView(spacer, new LinearLayout.LayoutParams(1, dp(dp)));
    }

    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(ColorStateList.valueOf(color));
        return b;
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF070D19);
        getWindow().setNavigationBarColor(0xFF070D19);

        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(0xFF070D19);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(25), dp(22), dp(25));
        scroller.addView(root);
        setContentView(scroller);

        TextView title = text("AURA LINE", 32, 0xFFBDF4FF);
        title.setLetterSpacing(0.19f);
        root.addView(title);
        root.addView(text("Liquid edge volume  •  alpha 0.1", 14, 0xFF93ABC7));
        gap(root, 19);

        FrameLayout preview = new FrameLayout(this);
        GradientDrawable wallpaper = new GradientDrawable(
                GradientDrawable.Orientation.BL_TR,
                new int[]{0xFF31265B, 0xFF172A5A, 0xFF0C152C});
        wallpaper.setCornerRadius(dp(22));
        preview.setBackground(wallpaper);
        preview.setClipToOutline(true);
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(335));
        root.addView(preview, previewLp);

        TextView hint = text("Tap UP or DOWN to see liquid motion", 13, 0xFFA9BAE5);
        FrameLayout.LayoutParams hintLp = new FrameLayout.LayoutParams(-2, -2,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        hintLp.bottomMargin = dp(20);
        preview.addView(hint, hintLp);
        demoLine = new AuraLineView(this);
        FrameLayout.LayoutParams lineLp = new FrameLayout.LayoutParams(dp(54), dp(236),
                Gravity.END | Gravity.TOP);
        lineLp.topMargin = dp(48);
        preview.addView(demoLine, lineLp);
        demoLine.showLevel(demoLevel / 100f, 1);

        gap(root, 15);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button down = button("↓  Volume down", 0xFF334B72);
        Button up = button("↑  Volume up", 0xFF1A7FAD);
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(56), 1f);
        half.rightMargin = dp(6);
        row.addView(down, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(56), 1f);
        half2.leftMargin = dp(6);
        row.addView(up, half2);
        root.addView(row);
        down.setOnClickListener(v -> simulate(-1));
        up.setOnClickListener(v -> simulate(1));
        gap(root, 20);

        root.addView(text("INSTALLATION", 14, 0xFF66DFFE));
        gap(root, 6);
        root.addView(text("1. Enable AURA LINE in LSPosed.\n2. Scope it to System UI (com.android.systemui).\n3. Reboot. Press a physical volume key to test.",
                14, 0xFFE3EAF8));
        gap(root, 18);

        root.addView(text("STOCK PANEL", 14, 0xFF66DFFE));
        gap(root, 8);
        replaceSwitch = new Switch(this);
        replaceSwitch.setText("Try hiding Samsung's volume panel");
        replaceSwitch.setTextSize(14);
        replaceSwitch.setTextColor(0xFFE3EAF8);
        boolean enabled = Settings.Global.getInt(getContentResolver(),
                AuraController.REPLACE_SETTING, 0) == 1;
        replaceSwitch.setChecked(enabled);
        root.addView(replaceSwitch);
        gap(root, 6);
        root.addView(text("EXPERIMENTAL: disabled by default. On some One UI builds the stock panel cannot be hidden by this generic hook. This setting requires a KernelSU root prompt.",
                12, 0xFF93ABC7));
        replaceSwitch.setOnCheckedChangeListener((compoundButton, checked) -> {
            if (checked) {
                new AlertDialog.Builder(this)
                        .setTitle("Experimental stock panel replacement")
                        .setMessage("First confirm AURA LINE appears when pressing your volume keys. Samsung-specific SystemUI hooks may fail. You can always turn this switch off to restore the stock panel.")
                        .setPositiveButton("Enable", (d, w) -> setReplace(true))
                        .setNegativeButton("Cancel", (d, w) -> refreshSwitch())
                        .show();
            } else {
                setReplace(false);
            }
        });
        gap(root, 25);
        root.addView(text("Renderer preview is real. SystemUI integration is experimental and has not yet been tested on a Galaxy S23 / Android 17.",
                12, 0xFF7F92AE));
    }

    private void simulate(int dir) {
        demoLevel = Math.max(0, Math.min(100, demoLevel + dir * 12));
        demoLine.showLevel(demoLevel / 100f, dir);
    }

    private void refreshSwitch() {
        int val = Settings.Global.getInt(getContentResolver(),
                AuraController.REPLACE_SETTING, 0);
        replaceSwitch.setOnCheckedChangeListener(null);
        replaceSwitch.setChecked(val == 1);
        replaceSwitch.setOnCheckedChangeListener((v, checked) -> {
            if (checked) {
                new AlertDialog.Builder(this).setTitle("Experimental hook")
                        .setMessage("Only enable after the custom line works with your physical keys. May not hide Samsung's stock panel.")
                        .setPositiveButton("Enable", (d, w) -> setReplace(true))
                        .setNegativeButton("Cancel", (d, w) -> refreshSwitch()).show();
            } else setReplace(false);
        });
    }

    private void setReplace(boolean enable) {
        new Thread(() -> {
            int exit = -1;
            try {
                String value = enable ? "1" : "0";
                Process p = new ProcessBuilder("su", "-c",
                        "settings put global " + AuraController.REPLACE_SETTING + " " + value)
                        .redirectErrorStream(true).start();
                exit = p.waitFor();
            } catch (Throwable ignored) { }
            final int result = exit;
            runOnUiThread(() -> {
                refreshSwitch();
                if (result != 0 || replaceSwitch.isChecked() != enable) {
                    new AlertDialog.Builder(this).setTitle("Root setting failed")
                            .setMessage("Allow KernelSU root access to AURA LINE, then try again.")
                            .setPositiveButton("OK", null).show();
                }
            });
        }, "aura-root-setting").start();
    }
}
