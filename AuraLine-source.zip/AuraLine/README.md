# AURA LINE — animated glass volume indicator (alpha v0.1)

This is the first **source-buildable** version of AURA LINE for a rooted Samsung Galaxy S23 / One UI 9 / Android 17 setup using LSPosed. The approved design is a slender, reflective edge tube, **no percentage**, cyan flowing highlight **up** for volume increase and **down** for decrease. The APK contains a live visual tester.

> **Status: source project; not a prebuilt or device-tested APK.** This version is experimental. I have not verified compatibility against Samsung's proprietary One UI 9 classes. Rendering is Canvas-simulated translucent/liquid glass, **not hardware-accurate iOS refraction**. Custom indicator uses a protected SystemUI overlay where allowed, with an application overlay fallback. KSU is needed only for the optional switch.

## How to build an APK with ONLY your phone (GitHub + Termux)

1. Download **AuraLine-source.zip** and extract it with Files to `Downloads/AuraLine/`. Check that `.github/workflows/build.yml` is present (some file managers hide dot-folders).
2. In [GitHub](https://github.com/), sign in and create an empty **private** repository called `aura-line` (do not create a README in GitHub).
3. Install **Termux** (prefer a current F-Droid or official GitHub build). Open Termux and enter:

```sh
termux-setup-storage
pkg update && pkg install git gh -y
cd ~/storage/downloads/AuraLine
git init
git add .
git commit -m 'AURA LINE alpha'
git branch -M main
gh auth login
gh auth setup-git
# Complete browser authentication when prompted.
git remote add origin https://github.com/YOUR_USERNAME/aura-line.git
git push -u origin main
```

   Replace `YOUR_USERNAME` with your own GitHub username. If git requests an identity, set a name and email using `git config --global user.name 'YourName'` and `git config --global user.email 'you@example.com'`, then retry the commit. Alternatively, use `gh repo create aura-line --private --source=. --remote=origin --push` after `gh auth login` without pre-creating a repo.
4. In your GitHub repository choose **Actions → Build AURA LINE APK → Run workflow**. It also builds automatically on a push to `main`.
5. Open the successful run. Under **Artifacts**, download `AuraLine-alpha-debug-apk.zip`, extract it, then install `app-debug.apk`.
6. Open **AURA LINE** and use the **UP** / **DOWN** demo buttons. The demo doesn't change real phone volume.
7. Open **LSPosed → Modules → AURA LINE**, enable it and select **System UI** (`com.android.systemui`) as its scope. Reboot your phone. Press your physical volume keys.
8. **Keep Samsung's stock volume panel enabled initially.** Only if you can see the custom line working with the physical volume keys, consider the **experimental stock replacement** switch in the AURA LINE app.

> If your Termux storage folder name differs, use `ls ~/storage/downloads` to find it. Use `.github` hidden folder when uploading; otherwise the GitHub workflow will not run.

## Safety / recovery

- **Default behavior is additive**: the stock volume dialog is **not** automatically hidden.
- If the optional stock replacement fails, turn its switch **off** from the AURA LINE app. If you cannot open the app, open a root shell and run `settings put global aura_line_replace_stock 0`.
- If SystemUI becomes unstable, turn off the AURA LINE module in **LSPosed** and reboot. You can also use a recovery/root shell to disable the offending LSPosed module. Do not edit or flash SystemUI.apk.
- Hidden Samsung volume classes and volume broadcasts can vary by build, so the real volume triggers and stock-panel hiding must be tested on the device.
- The module does not collect data, access the network, or modify on-disk SystemUI files.

## Architecture

- `AuraHook.java`: legacy Xposed/LSPosed entry; hooks `Application.attach` only in `com.android.systemui`, plus optional candidate AOSP volume hooks.
- `AuraController.java`: listens for `android.media.VOLUME_CHANGED_ACTION` with `VolumeDialogControllerImpl` fallback; renders in a tiny `TYPE_VOLUME_OVERLAY` (2020) window; auto-removes after fade-out. Stock replacement opt-in uses `Settings.Global`.
- `AuraLineView.java`: custom reflective dark-glass track, cyan liquid fill, upward/downward traveling highlight, no text or icons.
- `MainActivity.java`: on-device preview and recovery-friendly stock-hook toggle.
- `xposed-stubs`: **compile-time signature stubs only**, not included in the final APK. LSPosed supplies real framework classes at runtime. This avoids reliance on a now-hard-to-retrieve legacy API artifact.

## Known limitations

- Stock dialog replacement is **best effort** only. Samsung One UI may use other dialog classes.
- Real background refraction and wallpaper sampling are **not** implemented. Canvas drawing approximates the approved glass visual.
- Phone screen rotation/lockscreen positioning, multiple users and accessibility enhancements are not yet polished.
- The volume broadcast may be restricted by an OEM update. Logs can help confirm which signal is missing.

### Debugging

With a root-capable Termux shell:

```sh
su -c 'logcat -d -s AURA_LINE:* AndroidRuntime:E' | tail -120
```

This logs the reason if a Samsung hook or volume overlay is unavailable. Share the log (remove private data) to adapt the hook to your specific SystemUI build.
