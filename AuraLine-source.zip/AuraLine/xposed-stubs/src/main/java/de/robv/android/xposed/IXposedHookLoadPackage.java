package de.robv.android.xposed;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
/** Compile-time API signature ONLY. Supplied at runtime by LSPosed. */
public interface IXposedHookLoadPackage {
    void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable;
}
